# NeuraFlow Higgsfield Cowork Pack

Eight skills that turn Higgsfield into a full content pipeline inside Claude Cowork — UGC video ads, reusable characters, URL-to-ad, overnight batch runs, cinematic Instagram carousels, and infographics. No bounce-out to a separate app, no copy-paste between tabs.

## What's inside

| Skill | What it does |
| --- | --- |
| `setup-higgsfield-project` | One-time project init — writes a tailored `CLAUDE.md` that locks your brand voice, default character, output folders, and aspect ratios. Run this first. |
| `character-locker` | Save a UGC actor as a reusable character profile so every future ad uses the same face, outfit, and vibe. |
| `product-to-ad` | Drop in a product image, get back a finished UGC video ad — actor, scene, script, MP4. |
| `url-to-ad` | Paste a product URL. Claude scrapes the page and chains into the `product-to-ad` pipeline. |
| `ig-carousel` | Premium Instagram carousels — a cinematic cover plus content slides sharing the same visual world. |
| `overnight-content` | Schedule the full ad pipeline to run while you sleep — wake up to a folder of fresh ads. |
| `product-infographic` | Turns a product URL or photo into a listing infographic with feature callouts. |
| `explainer-infographic` | Turns a topic plus facts into one polished infographic image. |

## Requirements

- Claude Cowork (desktop app)
- Higgsfield MCP connected — Customize → Connectors → search Higgsfield → Connect (you'll need a Higgsfield account; Starter plan covers roughly 25–40 finished ads/month)

## Recommended order

1. `setup-higgsfield-project` — lock your project defaults
2. `character-locker` — save your hero UGC actor
3. `product-to-ad` or `url-to-ad` — make ads
4. `ig-carousel` — repurpose to social
5. `overnight-content` — automate the whole loop

## Install

Upload this `.zip` file directly to Claude as a plugin. Do **not** unzip it first.

---
NeuraFlow Academy · neuraflow.cloud
