# NeuraFlow Claude Connectors Pack

Four Claude Cowork skills built around connector-powered pipelines — three run on the Higgsfield MCP, one runs on your Gmail connector.

## What's inside

| Skill | What it does | Trigger |
|---|---|---|
| `explainer-infographic` | Turns a topic + facts into one polished infographic image | "make an infographic about..." |
| `product-infographic` | Turns a product URL or photo into a listing infographic with feature callouts | paste a product link + "listing infographic" |
| `product-to-ad` | Turns a product image into a finished UGC video ad | "turn this product into an ad" |
| `email-voice` | Studies your real sent emails and drafts replies that sound like you | "draft a reply", "set up my email voice" |

## What you need

1. **Claude Cowork** (desktop app)
2. **Higgsfield connector** for the three ad/infographic skills — Customize → Connectors → search Higgsfield → Connect (needs a Higgsfield account; infographics cost ~1 credit, a full UGC ad ~5–8 credits)
3. **Gmail connector** for email-voice — Settings → Connectors → Gmail (read-only, never sends on its own)

## Install

Upload this `.zip` file directly to Claude as a plugin. Do **not** unzip it first — type `/` in Cowork afterward and you'll see all four skills.

---
NeuraFlow Academy · neuraflow.cloud
