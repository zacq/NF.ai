# NeuraFlow Cowork Skills Starter Pack

15 ready-to-install Claude Cowork skills covering the tasks that eat the most time in a small business or agency — content, admin, research, and reporting.

## Skills Included

1. Slide Deck Builder
2. Customize
3. Difficult Conversation Prep
4. Receipt Scanner
5. Explainer Graphic
6. Email Drafter
7. Visual Page Builder
8. Invoice Generator
9. Contract Reviewer
10. Workflow Visualizer
11. Morning Briefing
12. Budget Dashboard
13. Quick Research
14. Animated Website
15. Learning Path Generator

## How to Install

1. Open Claude Desktop
2. Go to Cowork mode
3. Click the plugin icon
4. Upload this `.plugin` file
5. All 15 skills are ready to use immediately

## Pair Skills with Scheduled Tasks

Skills get more useful when paired with Cowork's scheduled tasks — a task that runs automatically on a schedule you set, so Claude does the work in the background without you being there.

A few combinations worth setting up:

- **Morning Briefing + daily schedule** — run it every morning at 7am and wake up to a briefing on what's happening in your space, already sitting in your folder.
- **Receipt Scanner + weekly schedule** — drop receipts into a folder all week, then have Claude build your expense report every Friday.
- **Quick Research + on demand** — fire off a research task whenever a competitor moves or news breaks.
- **Budget Dashboard + monthly schedule** — auto-generate an updated budget report on the 1st of every month.

To set one up, just tell Claude: "Schedule the morning briefing to run every day at 7am" and it handles the rest. Any scheduled task can also be triggered manually whenever you want.

Skills (what Claude knows how to do) plus scheduled tasks (when it does it) is what turns Cowork from a chatbot into a system that works for you.

---
NeuraFlow Academy · neuraflow.cloud
