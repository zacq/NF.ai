# NeuraFlow Animated Scroll Website Skill

A Claude skill that turns a video clip (MP4, MOV, or WebM) into a premium, scroll-driven website — scrolling controls a frame-by-frame canvas sequence, like an Apple-style product launch page or a cinematic portfolio reel.

## What it builds

- Cinematic product launches, automotive showcases, portfolio films
- Apple-style scrollytelling with engineered pacing and progressive loading
- A distinctive editorial design system generated around your subject, not a generic template

## How to install

1. Unzip this pack.
2. Place the `animated-website` folder inside your Claude project's skills directory (`.agents/skills/` or wherever your Claude Cowork/Code setup expects skills).
3. Trigger it by asking Claude to turn a video into an animated/scroll-driven website — see `animated-website/SKILL.md` for the full workflow, frame-count guidance, and design system reference.

## What's inside

- `SKILL.md` — the full workflow Claude follows: inspecting the footage, setting a design thesis, extracting frames, writing the scroll story, and building the site.
- `references/visual-system.md` — a detailed design-system reference for building a subject-specific visual identity.
- `scripts/extract_frames.py` — deterministic, ffmpeg-based frame extraction.
- `assets/starter.html` — a reusable starter implementing the scroll-remap canvas engine.
- `evals/evals.json` — test prompts for evaluating the skill's output.

Requires `ffmpeg`/`ffprobe` available on your system for frame extraction.

---
NeuraFlow Academy · neuraflow.cloud
