# Dashboard Components — copy/paste snippets

Copy-paste HTML for the most common components. All styles live in `template.html` — these snippets assume that CSS is already loaded on the page.

---

## Stat bar

```html
<div class="stats">
  <div class="stat">
    <div class="stat-num">12</div>
    <div class="stat-label">Emails</div>
  </div>
  <div class="stat">
    <div class="stat-num">4</div>
    <div class="stat-label">Meetings</div>
  </div>
  <div class="stat">
    <div class="stat-num">3</div>
    <div class="stat-label">Priorities</div>
  </div>
  <div class="stat">
    <div class="stat-num">7</div>
    <div class="stat-label">Tasks</div>
  </div>
</div>
```

Rules:
- 3 to 5 stats per bar. Any more than 5 becomes noise.
- Stat numbers are Instrument Serif, always in Claude orange (`--claude`).
- Labels are 11px, uppercase, letter-spaced, in `--text-muted-light`.

---

## Info card (cream on dark)

```html
<div class="card">
  <h3>Card title</h3>
  <p>One to three short lines of supporting copy. Keep it scannable.</p>
</div>
```

Put several cards in a grid:

```html
<div class="card-grid">
  <div class="card">...</div>
  <div class="card">...</div>
  <div class="card">...</div>
</div>
```

Rules:
- Cream background (`--surface`), dark text inside. Never dark card on dark bg.
- Corners at 14px.
- Title in Instrument Serif 22px, body in Inter 15px.

---

## Category section

```html
<section>
  <h2>Your <em>priorities</em></h2>
  <p class="section-sub">Short one-line description of what this section covers.</p>
  <div class="card-grid">
    <div class="card"><h3>Item</h3><p>Detail.</p></div>
    <div class="card"><h3>Item</h3><p>Detail.</p></div>
  </div>
</section>
```

Optional subtitle styling (add to template CSS if not present):

```css
.section-sub {
  color: var(--text-secondary-light);
  font-size: 15px;
  margin: -8px 0 20px;
  line-height: 1.55;
  max-width: 680px;
}
```

Rules:
- Every h2 italicizes exactly one word in Claude orange. Pick the most important word.
- Use `<section>` tags so the fade-in animation works.

---

## Badge with pulsing dot

```html
<div class="badge">
  <span class="badge-dot"></span>
  <span>Pipeline</span>
</div>
```

Common badge labels by dashboard type:
- Morning briefing → `Today&#39;s briefing`
- Pipeline dashboard → `Pipeline`
- End of day / wrapup → `End of day`
- Research / analytics → `Research`
- Audit / weekly review → `Audit`

---

## Modal / overlay

```html
<div class="modal-backdrop" id="modal">
  <div class="modal-card">
    <button class="modal-close" onclick="document.getElementById(&#39;modal&#39;).classList.remove(&#39;open&#39;)">&times;</button>
    <h2>Modal title</h2>
    <p>Modal content goes here.</p>
  </div>
</div>
```

Add to template CSS:

```css
.modal-backdrop {
  position: fixed; inset: 0; z-index: 1000;
  background: rgba(10, 7, 4, 0.75);
  display: none;
  align-items: center; justify-content: center;
  padding: 24px;
}
.modal-backdrop.open { display: flex; }
.modal-card {
  background: var(--surface);
  color: var(--text-dark);
  border-radius: 20px;
  padding: 32px;
  max-width: 560px;
  width: 100%;
  position: relative;
}
.modal-close {
  position: absolute; top: 14px; right: 14px;
  background: none; border: none; cursor: pointer;
  font-size: 22px; color: var(--text-muted-light);
}
```

---

## Audit panel (weekly review / health score)

```html
<section class="audit">
  <div class="audit-score">
    <svg viewBox="0 0 120 120" class="score-ring">
      <circle cx="60" cy="60" r="52" stroke="rgba(245,237,228,0.1)" stroke-width="8" fill="none"/>
      <circle cx="60" cy="60" r="52" stroke="var(--claude)" stroke-width="8" fill="none"
              stroke-dasharray="326.7" stroke-dashoffset="65.3"
              stroke-linecap="round" transform="rotate(-90 60 60)"/>
    </svg>
    <div class="score-value">80</div>
    <div class="score-label">Health</div>
  </div>
  <div class="audit-recs">
    <h3>Top <em>3 actions</em> this week</h3>
    <ul>
      <li><span class="pri pri-high">HIGH</span> Fix the broken IG carousel pipeline</li>
      <li><span class="pri pri-med">MED</span> Consolidate three overlapping research skills</li>
      <li><span class="pri pri-low">LOW</span> Archive the old briefing template</li>
    </ul>
  </div>
</section>
```

Add to template CSS:

```css
.audit { display: grid; grid-template-columns: 180px 1fr; gap: 32px; align-items: center;
         background: var(--surface); color: var(--text-dark); border-radius: 14px; padding: 28px; }
.audit-score { position: relative; width: 120px; height: 120px; }
.audit-score svg { width: 120px; height: 120px; }
.score-value { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
               font-family: 'Instrument Serif', serif; font-size: 36px; color: var(--claude); }
.score-label { position: absolute; bottom: -18px; left: 0; right: 0; text-align: center;
               font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--text-muted-light); }
.audit-recs ul { list-style: none; margin-top: 10px; }
.audit-recs li { padding: 10px 0; border-bottom: 1px solid var(--border);
                 font-size: 15px; display: flex; gap: 12px; align-items: center; }
.audit-recs li:last-child { border-bottom: none; }
.pri { display: inline-block; font-size: 10px; font-weight: 700; letter-spacing: 0.1em;
       padding: 3px 8px; border-radius: 100px; text-transform: uppercase; }
.pri-high { background: rgba(196,97,63,0.15); color: var(--claude-dark); }
.pri-med  { background: rgba(196,162,101,0.15); color: var(--warm-gold); }
.pri-low  { background: rgba(26,23,20,0.08); color: var(--text-muted-light); }
```

Rules:
- Score ring circumference is 326.7 (2π × 52). `stroke-dashoffset` is `326.7 × (1 - score/100)`.
- Priority pills: HIGH / MED / LOW only — do not invent new tiers.

---

## CTA pill

```html
<a href="#" class="cta">View full report</a>
```

```css
.cta {
  display: inline-block;
  padding: 10px 20px;
  border-radius: 100px;
  background: var(--claude);
  color: #fff;
  font-weight: 600;
  font-size: 14px;
  text-decoration: none;
  transition: background 0.2s ease, transform 0.2s ease;
}
.cta:hover { background: var(--claude-dark); transform: translateY(-1px); }
```

---

## Lucide-style icon pattern

Never use emoji as section icons. Use inline SVG in the line-icon style:

```html
<svg viewBox="0 0 24 24" width="18" height="18" fill="none"
     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M12 2v20M2 12h20"/>
</svg>
```

Color the icon with `color: var(--claude)` where it should pop, or `color: var(--text-muted-light)` for neutral.
