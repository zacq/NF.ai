#!/usr/bin/env python3
"""
skills-audit
============
Reads the skill-dashboard's index.json, runs a series of hygiene checks,
and writes audit.json next to it. The dashboard's build script picks
that file up on its next run and renders an audit panel at the top.

Checks performed:
  1. Duplicates  - same skill name installed by multiple plugins
  2. Overlaps    - many skills doing the same thing (slides, research, etc.)
  3. Bootstrap   - low-value setup skills that may be safe to uninstall
  4. Broken      - SKILL.md/command paths that no longer exist on disk
  5. Health      - one composite 0-100 score so the dashboard has a hero metric

Usage:
  python3 audit.py \
    --in  "/path/to/skill-dashboard/index.json" \
    --out "/path/to/skill-dashboard/audit.json"
"""

import argparse
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path


# ---------- Overlap groups ----------
# Each group is a (label, keyword_set) — if 3+ skills match keywords from
# the same group, we flag it as an overlap.
OVERLAP_GROUPS = [
    ("Slideshow / deck builders",       {"slide", "slides", "deck", "presentation", "infographic"}),
    ("Research tools",                  {"research", "quick-research", "deep-dive", "investigate"}),
    ("Morning briefings",               {"morning", "briefing", "daily-brief"}),
    ("Email / inbox tools",             {"email", "inbox", "gmail", "draft"}),
    ("Meeting prep / notes",            {"meeting", "standup", "notes"}),
    ("Hook / opener writers",           {"hook", "opener", "intro"}),
    ("Receipt / expense scanners",      {"receipt", "expense", "invoice"}),
    ("Workflow / system visualizers",   {"workflow", "diagram", "visualizer", "visual-page", "explainer"}),
    ("Title / thumbnail generators",    {"thumbnail", "title-generator", "yt-title"}),
    ("Travel planners",                 {"travel", "trip", "itinerary"}),
    ("Budget / finance planners",       {"budget", "finance", "savings"}),
    ("Habit / goal trackers",           {"habit", "goal", "tracker"}),
    ("Contract / legal review",         {"contract", "nda", "legal", "review"}),
    ("Memory / context tools",          {"memory", "context-builder"}),
    ("Repurpose / content adapters",    {"repurpose", "blog-from", "video-to", "social-repurposer"}),
]


# Names that indicate the skill is bootstrap/setup-only (used once, then ignored).
# These are candidates for uninstall after the user is set up.
BOOTSTRAP_TOKENS = {
    "begin", "start", "go", "tour", "reset", "customize",
    "ideas", "init", "setup", "kickstart",
}


# ---------- Helpers ----------
def slug_tokens(name: str) -> set:
    """Lowercase tokens from a skill slug, e.g. 'slide-deck-builder' -> {'slide','deck','builder'}."""
    if not name:
        return set()
    return set(re.split(r"[-_:/\s]+", name.lower()))


def short_source(src: str) -> str:
    """'cowork-essentials:slide-deck-builder' -> 'cowork-essentials'."""
    if not src:
        return "?"
    return src.split(":", 1)[0].split("/")[0]


# ---------- Audit checks ----------
def check_duplicates(items):
    """Same raw_name installed under 2+ different sources."""
    groups = defaultdict(list)
    for it in items:
        raw = it.get("raw_name") or it.get("name", "").lower()
        groups[raw].append(it)
    findings = []
    for raw, group in groups.items():
        if len(group) >= 2:
            sources = sorted({short_source(g.get("source", "")) for g in group})
            if len(sources) >= 2:
                findings.append({
                    "name": raw,
                    "count": len(group),
                    "sources": sources,
                    "recommendation": (
                        f"Same skill installed {len(group)} times across {len(sources)} sources. "
                        f"Pick one and uninstall the rest to reduce noise."
                    ),
                })
    findings.sort(key=lambda f: -f["count"])
    return findings


def check_overlaps(items):
    """Multiple skills doing the same thing based on keyword groups."""
    findings = []
    for label, keywords in OVERLAP_GROUPS:
        matches = []
        for it in items:
            tokens = slug_tokens(it.get("raw_name", ""))
            if tokens & keywords:
                matches.append(it)
        # Dedupe by raw_name so duplicates don't double-count here
        unique_names = sorted({m.get("raw_name", m.get("name", "")) for m in matches})
        if len(unique_names) >= 3:
            findings.append({
                "category": label,
                "count": len(unique_names),
                "skills": unique_names[:10],  # cap displayed list
                "recommendation": (
                    f"You have {len(unique_names)} skills that overlap on '{label.lower()}'. "
                    f"Standardize on one as your default and uninstall the rest."
                ),
            })
    findings.sort(key=lambda f: -f["count"])
    return findings


def check_bootstrap(items):
    """Setup-only skills that are safe to remove after onboarding."""
    findings = []
    for it in items:
        tokens = slug_tokens(it.get("raw_name", ""))
        if tokens & BOOTSTRAP_TOKENS:
            findings.append({
                "name": it.get("name") or it.get("raw_name"),
                "source": short_source(it.get("source", "")),
                "kind": it.get("kind", ""),
                "recommendation": (
                    "Bootstrap / setup-only — safe to uninstall after initial configuration."
                ),
            })
    return findings[:20]


def check_broken(items):
    """SKILL.md paths that don't exist on disk."""
    findings = []
    for it in items:
        p = it.get("path")
        if not p:
            continue
        if not os.path.exists(p):
            findings.append({
                "name": it.get("name") or it.get("raw_name"),
                "source": short_source(it.get("source", "")),
                "path": p,
                "recommendation": "File no longer exists. Plugin may be partially uninstalled — clean up the orphan.",
            })
    return findings[:25]


# ---------- Health score ----------
def compute_health(total, dup_count, overlap_groups, bootstrap_count, broken_count):
    if total == 0:
        return 0
    # Penalty per finding type, capped so any single category can't tank the score alone.
    dup_penalty       = min(dup_count * 1.5, 25)
    overlap_penalty   = min(overlap_groups * 4,  25)
    bootstrap_penalty = min(bootstrap_count * 0.5, 10)
    broken_penalty    = min(broken_count * 5,  30)
    score = 100 - (dup_penalty + overlap_penalty + bootstrap_penalty + broken_penalty)
    return max(0, min(100, round(score)))


def health_grade(score):
    if score >= 90: return ("Excellent",  "#22c55e")
    if score >= 75: return ("Healthy",    "#84cc16")
    if score >= 60: return ("Cluttered",  "#f59e0b")
    if score >= 40: return ("Bloated",    "#f97316")
    return ("Overgrown", "#ef4444")


# ---------- Top recommendations ----------
def top_recommendations(dups, overlaps, bootstrap, broken):
    """A short, ranked action list — what the user should do this week."""
    recs = []
    if broken:
        recs.append({
            "priority": "high",
            "title": f"Clean up {len(broken)} broken skill reference(s)",
            "detail": "These skills point to files that no longer exist.",
        })
    if overlaps:
        biggest = overlaps[0]
        recs.append({
            "priority": "high",
            "title": f"Pick one '{biggest['category']}' skill",
            "detail": f"You have {biggest['count']} doing roughly the same job.",
        })
    if dups:
        biggest = dups[0]
        recs.append({
            "priority": "medium",
            "title": f"Resolve duplicates of '{biggest['name']}'",
            "detail": f"Installed {biggest['count']} times across {len(biggest['sources'])} sources.",
        })
    if bootstrap:
        recs.append({
            "priority": "low",
            "title": f"Uninstall {len(bootstrap)} bootstrap-only skill(s)",
            "detail": "Setup helpers you've already used — safe to remove.",
        })
    return recs[:5]


# ---------- Main ----------
def run(in_path, out_path):
    src = Path(in_path)
    if not src.exists():
        raise SystemExit(f"[error] index.json not found at {src}")

    items = json.loads(src.read_text(encoding="utf-8"))
    print(f"[scan] Auditing {len(items)} skills/commands...")

    dups       = check_duplicates(items)
    overlaps   = check_overlaps(items)
    bootstrap  = check_bootstrap(items)
    broken     = check_broken(items)

    score = compute_health(
        total=len(items),
        dup_count=len(dups),
        overlap_groups=len(overlaps),
        bootstrap_count=len(bootstrap),
        broken_count=len(broken),
    )
    grade_label, grade_color = health_grade(score)

    audit = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "total_items": len(items),
        "health": {
            "score": score,
            "label": grade_label,
            "color": grade_color,
        },
        "summary": {
            "duplicates": len(dups),
            "overlaps": len(overlaps),
            "bootstrap": len(bootstrap),
            "broken": len(broken),
        },
        "recommendations": top_recommendations(dups, overlaps, bootstrap, broken),
        "findings": {
            "duplicates": dups,
            "overlaps":   overlaps,
            "bootstrap":  bootstrap,
            "broken":     broken,
        },
    }

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(f"[done] Audit written to: {out}")
    print(f"[score] Health: {score}/100  ({grade_label})")
    print(f"[counts] duplicates={len(dups)}  overlaps={len(overlaps)}  bootstrap={len(bootstrap)}  broken={len(broken)}")


def main():
    ap = argparse.ArgumentParser()
    default_in  = Path(__file__).resolve().parent.parent / "skill-dashboard" / "index.json"
    default_out = Path(__file__).resolve().parent.parent / "skill-dashboard" / "audit.json"
    ap.add_argument("--in",  dest="in_path",  default=str(default_in),  help="Path to dashboard index.json")
    ap.add_argument("--out", dest="out_path", default=str(default_out), help="Path to write audit.json")
    args = ap.parse_args()
    run(args.in_path, args.out_path)


if __name__ == "__main__":
    main()
