---
name: obsidian-daily-note-test
description: Generate tomorrow's daily note in an Obsidian vault, pre-filled with tomorrow's calendar, unchecked action items carried forward from today's note, a goals check-in, and any recent meeting follow-ups. Use when the user says "obsidian daily note", "generate tomorrow's daily note", "build my daily note", "prep tomorrow's daily note", "second brain daily note", "set up tomorrow in obsidian", "end of day obsidian run", or any variation of wanting tomorrow's Obsidian daily note prepared. First-time run asks for the vault path and folder structure, then saves it for reuse.
---

# Obsidian Daily Note

Generate tomorrow's daily note in the user's Obsidian vault, pre-filled with calendar events, carried-forward action items, a goals check-in, and recent meeting follow-ups.

## First-time setup

Before the first run, ask the user for their vault config and save it to a config file (e.g. `~/.config/obsidian-daily-note/config.json` or the project's `.claude/obsidian-daily-note.json`). Keep this one-time so future runs don't re-ask.

Ask for:
- **Vault path** (absolute path to the Obsidian vault folder, e.g. `~/Documents/Second-Brain/`)
- **Daily Notes folder** inside the vault (default: `Daily Notes/`)
- **Goals folder** inside the vault (default: `Goals/`)
- **Goals file** — the current goals doc to read for check-ins (e.g. `q2-2026-goals.md`). Optional.
- **Goal areas** — a list of buckets the user tracks (default: `["Work", "Personal"]`; the user can replace with whatever categories they actually use)
- **Meeting Notes folder** (default: `Meeting Notes/`). Optional.
- **Pipeline folder** — optional folder to pull active projects from (e.g. `YouTube Videos/In Progress/` or `Projects/Active/`). Skip if not relevant.

If a config already exists, load it and confirm before generating. If the user wants to change it later, they can say "update my obsidian config."

## What to do

1. **Get tomorrow's date.** Format as `YYYY-MM-DD` and determine the day of the week. Use `date` via bash so you have the real current date — don't guess.

2. **Pull tomorrow's calendar events** (if a calendar connector is available). Use whatever calendar MCP tool is connected (Google Calendar, Apple Calendar, Outlook, etc.) for tomorrow's date range. Include all events with their start times. If no calendar connector is available, leave a placeholder line the user can fill in. If nothing is scheduled, write "No meetings — full deep work day."

3. **Read today's daily note.** Look in `{vault}/{daily_notes_folder}/` for today's file (`YYYY-MM-DD.md`). Pull:
   - Anything under the "Tomorrow" section
   - Any unchecked action items (`- [ ]`) to carry forward
   - Any "Ideas / Insights" worth surfacing

4. **Read the goals file** at `{vault}/{goals_folder}/{goals_file}` (if configured) so you can write a quick check-in on each goal area. If the file doesn't exist, flag that inline in the note.

5. **Scan the pipeline folder** (if configured). List its contents to build an Active Pipeline table.

6. **Read recent meeting notes** (if the meeting notes folder is configured). Check for any files from the last 3 days and carry forward open action items.

7. **Write the daily note** to `{vault}/{daily_notes_folder}/YYYY-MM-DD.md` using the template below.

8. **Verify the file was created** by reading it back.

9. **Share the file** with a `computer://` link so the user can open it with one click.

## Vault bootstrap

If the configured folders don't exist yet, create them. Flag missing source files (no prior daily note, no goals file, empty pipeline) inline in the note rather than leaving sections blank.

## Template

```
---
date: YYYY-MM-DD
tags: [daily-note]
---

# [Day of Week], [Full Date]

## Calendar
[Tomorrow's events with times, or "No meetings — full deep work day."]

## What I'm Working On
[Pull from today's "Tomorrow" section and any carried-forward items. Use wiki links to connect to relevant notes.]

## Open Action Items (carried forward)
[Unchecked items from today's note and recent meeting notes. Use `- [ ]` for open, `- [x]` for completed.]

## Active Pipeline
| Project | Status | Next Step |
|---------|--------|-----------|
[Pull from the configured pipeline folder, if any]

## Goals Check-in
[Brief status on each configured goal area]

## Ideas / Insights
- 

## Tomorrow
- 
```

If the user's goal areas are `["YouTube", "Business", "Personal"]`, the check-in section has one sub-heading per area. Adapt the template to fit their categories.

## Rules

- **Always use wiki links** (`[[like-this]]`) when referencing other notes — it keeps the Obsidian graph connected.
- **Don't leave sections blank.** If there's nothing to carry forward, say so inline (e.g., "_No open action items from today._").
- **Seed content from real sources.** Pull from the actual files listed in the config rather than dropping placeholder bullets.
- **Don't overwrite an existing file** for the same date without confirming with the user first.
- **End with a `computer://` link** to the new daily note so the user can open it with one click.

## Customizing

The defaults above are a starting point. Tell the user they can:
- Add or remove sections from the template
- Swap `Daily Notes/` for whatever folder name they actually use
- Disable calendar/pipeline/meeting-notes sections if they don't need them
- Change the goal areas list to match their own categories

Update the config file when the user asks to change any of this.

## Interactive behavior

This skill runs interactively, so:
- If the user triggers it mid-day and today's note still has unsaved "Tomorrow" items, ask if they want to finalize today's note first.
- If there's already a daily note for tomorrow's date, ask before overwriting.
- Surface choices (e.g., "Goals file is missing — create a stub?") rather than silently filing them away in a summary.
