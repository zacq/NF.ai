---
name: ig-carousel-test
description: Generate premium Instagram carousel posts using Gemini (Nano Banana Pro). Starts with a cinematic cover (photorealistic 3D scene), then generates content slides inside that same cinematic world. Output: 1080x1350 portrait (4:5) PNGs. Two modes — (1) from scratch, give a topic; (2) repurpose, give a YouTube video or transcript. First-time run walks through a one-time setup to save your Instagram handle, CTA, and accent color. Use when the user says "carousel", "Instagram carousel", "IG carousel", "make a carousel", "carousel post", "repurpose to carousel", "Instagram post", or wants slide-based social content.
---

# Instagram Carousel Generator (Cinematic + Gemini)

Every carousel = **cinematic cover first, then content slides that live inside the same cinematic world**. The cover sets the scene (gothic library, deserted island, late-night desk, etc.). Every following slide reuses that exact scene as its background, so the whole carousel feels like one photo shoot — not a flat deck with a photoreal cover glued on top.

---

## First-time setup

Before generating the first carousel, ask the user for their defaults and save them to a config file (e.g. `~/.config/ig-carousel/config.json` or the project's `.claude/ig-carousel.json`). Keep this one-time so future runs don't re-ask.

Ask for:
- **Instagram handle** (e.g. `@yourhandle`)
- **Brand accent color** (hex) — default salmon/orange `#DA7756` if they don't have one
- **CTA slide text** (e.g. "Follow for more tips" + any community/newsletter/link)
- **Preferred scene library** — optional list of recurring scenes they like (library, cabin, desert, etc.) so you can suggest scenes on brand

If a config file already exists, just load it and confirm before generating.

---

## Visual style

### Cinematic cover (slide 1 — always)
Full photorealistic 3D rendered scene. Optionally includes a focal object that represents the user's work (a retro CRT, a typewriter, a specific tool) — ask the user on first setup if they want a recurring focal prop.

- **Scene:** A photorealistic 3D environment that metaphorically represents the topic
  - Learning / courses → gothic library, bookshelves, arched windows, golden light
  - Productivity / tools → sleek modern office, late-night desk, coffee + sticky notes
  - Essentials / favorites → deserted island, cozy cabin, dramatic landscape
  - News / announcements → futuristic lecture hall, newsroom, command center
  - Automation / sleep → moonlit bedroom, midnight cityscape
- **Focal prop (optional, user-defined):** A recurring object on a beautiful surface that becomes the carousel's signature (retro CRT, typewriter, polaroid, etc.)
- **Props:** Theme-matching objects around the focal prop (books + banker's lamp for learning, palm trees for island, etc.)
- **Lighting:** Warm golden/amber volumetric light rays, cinematic, dramatic shadows, depth of field blur
- **Text overlay:**
  - Large number/count in the user's accent color, massive, upper area (if applicable)
  - Key words in bold white italic serif (Playfair Display / editorial serif)
  - Accent word in the user's accent color, italic serif
  - Arranged artfully in upper ~45% of the frame
- **Hook phrase (bottom):** Elegant white italic serif, smaller, ending in "..."
  - Examples: "that will make you dangerous...", "I would bring to a deserted island...", "you didn't know existed..."
- **Footer:** `{handle}` left, "save for later" right in white italic, subtle dark gradient

### Content slides (inside the same cinematic world)
These MUST feel like they were shot inside the cover's scene. Same library, same desk, same moonlit bedroom — just a different angle or a new element in the frame.

- **Background:** The exact same scene as the cover
- **Lighting:** Same warm amber volumetric light, same depth of field, same grain
- **Content element:** A photoreal object placed into the scene — an open leather journal, a floating paper card, a CRT screen close-up, a lit index card pinned to a corkboard, etc.
  - Text lives ON that object (handwritten on the journal, printed on the card, glowing on a screen)
  - Monospace code blocks = on a paper card or a screen close-up; handwritten tips = on a journal page
- **Typography:** Editorial serif italic headlines (Playfair Display style) in white + accent-color highlights. Monospace only when shown as code on-screen.
- **Footer:** `{handle}` left, bookmark / "save for later" right. No carousel dots — Instagram adds its own.

### CTA slide (last)
Same cinematic scene. Brand element centered (could be a logo, glow, or signature object). The user's CTA text in editorial serif. If they have a community/newsletter/link, include it as a pill button.

---

## Two modes

### Mode 1: From scratch
User provides a topic. Pick the scene that metaphorically fits the topic, then generate cover + 3-5 content slides + CTA.

### Mode 2: YouTube repurpose
User provides a YouTube URL or transcript. Extract the most actionable moments into carousel slides. Still uses the cinematic cover + same-world content slides pattern.

---

## Process

### Step 1: Load or create config
If no config file exists, run the first-time setup (handle, accent color, CTA text, optional focal prop). Otherwise load the existing one.

### Step 2: Pick the scene
Choose one cinematic scene that communicates the topic BEFORE the viewer reads any text. This scene anchors every slide in the carousel.

### Step 3: Plan the slides
- **Slide 1:** Cinematic cover (title + scene + optional focal prop + hook phrase) — this IS the hook
- **Slides 2-6:** Content inside the same scene (tips, prompts, comparisons) — each one is a new object in the world (journal page, paper card, screen close-up)
- **Last slide:** CTA (from config) — same scene

**No context slides, no transition slides, no "most people do X wrong" filler.** The cover already hooks. Every slide after the cover delivers concrete value.

**Directional gestures:** Never use downward-pointing emojis (👇). Instagram carousels scroll horizontally — use 👉, ➡️, or "swipe right" gestures.

### Step 4: Build the data JSON

```json
{
  "handle": "{from config}",
  "accent": "{from config}",
  "slides": [
    {
      "name": "01_cover",
      "kind": "cover_cinematic",
      "prompt": "SCENE: gothic library at night, floor-to-ceiling oak bookshelves, arched windows with moonlight spilling through, leather armchairs, Persian rug. [optional focal prop from config] on a carved wooden desk in the foreground. Banker's lamp beside it, stacks of old books, quill pen.\n\nTEXT OVERLAY:\n- '7' in {accent}, massive, upper left\n- 'Something powerful' in bold white italic serif\n- 'that will change your workflow' in {accent} italic serif\n\nHOOK PHRASE (bottom): 'the ones no one talks about...' in white italic serif\n\nFOOTER: {handle} left, 'save for later' right.\n\nPhotorealistic 3D render, warm golden volumetric light, depth of field, film grain, movie-poster feel."
    },
    {
      "name": "02_slide_1",
      "prompt": "Same gothic library scene as the cover — same bookshelves, same amber moonlight, same desk. An open leather journal is now placed on the desk in the foreground, catching the banker's lamp glow.\n\nON THE JOURNAL (handwritten ink):\n- Headline: 'Tip Name' in editorial serif italic, 'accent phrase' in {accent}\n- 3 short bullet lines in handwritten-looking ink\n\nFOOTER unchanged."
    }
  ]
}
```

### Step 5: Generate

```bash
python3 .claude/skills/ig-carousel/scripts/render_carousel.py \
  --data /tmp/carousel_data.json \
  --output outputs/carousels/{slug}/
```

**How the script works:**
1. Loads an optional brand logo/icon (if the user saved one during setup). Override with `ICON_PATH` env var.
2. **Phase 1 — cinematic cover:** sends the optional icon + cover prompt to Gemini. No external style reference — the prompt defines the cinematic scene.
3. **Phase 2 — content slides:** uses the **just-generated cover** as the style reference for every remaining slide. This is what locks the whole carousel into the same cinematic world.
4. All slides resized to exactly 1080x1350 with PIL LANCZOS.

If the cover fails, the script retries once then aborts — the cover MUST succeed before content slides, because every content slide depends on it as the style anchor.

### Step 6: Review, then caption

Open all slides and show inline. Ask for feedback. Generate the Instagram caption:
- Hook line (question or bold statement)
- 2-3 lines of value
- CTA: "Save this" or "Which one are you trying first?"
- Up to 5 hashtags
- User's handle/follow line from config

---

## Content guidelines

### Headlines
- 5-10 words max, editorial serif italic
- Accent the BENEFIT word, not the tool name
- Frame as outcome: "Never miss a message again" not "How to use Slack catchup"

### Prompt slides (inside the cinematic scene)
- Show the prompt on a photoreal paper index card or a screen close-up
- 6-12 lines of monospace text — keep it copy-paste ready
- Key terms highlighted in the accent color

### Explainer slides
- One bold headline in editorial serif italic
- 3-4 supporting bullets on a photoreal journal/card
- Plain-English, 5th grade reading level

### Comparison slides
- Split the scene: two objects side by side inside the same room (two journals, two cards)
- Colored header on each, 4-5 bullets per side

---

## Output

```
outputs/carousels/{slug}/
├── 01_cover.png          ← cinematic cover (generated first, no style ref)
├── 02_slide_1.png        ← same scene, journal page
├── 03_slide_2.png        ← same scene, screen close-up
├── ...
├── XX_cta.png            ← same scene, CTA
└── caption.txt
```

---

## Default rules (customizable)

- Always use Nano Banana Pro (`gemini-3-pro-image-preview`). No Playwright/HTML fallback — this skill is cinematic AI-rendered only.
- Always cinematic cover first. If the user wants a flat/terminal-style carousel instead, that's a different workflow.
- Always use the generated cinematic cover as the style reference for every subsequent slide (the script does this automatically).
- Every slide must be 1080x1350 (4:5 portrait). PIL LANCZOS resize after generation.
- Sleep 3 seconds between API calls to avoid rate limits.
- Include the user's handle (from config) on every slide. CTA line appears on the final slide.
- Keep the accent color consistent across all slides (from config).
- Warm dark tones by default — no cold grays, no pure black, no teal/purple/neon. Override if the user wants a different aesthetic.

### Visual consistency (important)
- **Same scene across all slides.** If the cover is a gothic library, every content slide is INSIDE that same library. Different angle, different object — but same room, same lighting, same palette.
- **Content lives on photoreal objects inside the scene** (journal, paper card, screen, pinned index card) — not on a flat colored background floating in front of the scene.
- **Editorial serif italic (Playfair Display style)** for headlines and accents. Monospace only when rendered as code on-screen.
- **Skip filler context/explainer slides** (e.g. "Most people just chat..."). The cover is the hook. Go Cover → Value → Value → Value → CTA.
- **Do not auto-publish.** After generating, ask the user: "Ready to post? (1) Post now, (2) Schedule, (3) Save for later."

### Optional publishing flow
If the user wants to auto-post via a social scheduler (Blotato, Buffer, Later, etc.), they'll need to configure the relevant connector and paste their account ID into the config file. This skill does not hardcode a scheduler — ask which one they use and adapt.

## Requirements

- Python 3 with `google-generativeai`, `Pillow`, and `requests` installed
- A Google Gemini API key (`GEMINI_API_KEY` env var)
- Gemini Nano Banana Pro access (`gemini-3-pro-image-preview`)
