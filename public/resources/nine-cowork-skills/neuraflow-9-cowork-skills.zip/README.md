# NeuraFlow 9 Cowork Skills

Nine Claude Cowork skills, packaged as one installable plugin: a brand-locked HTML/dashboard style system, a skill finder, a visual explainer, a polished PDF guide builder, a skills dashboard and audit pair, an end-of-day summary, an Obsidian daily note prep, and a cinematic Instagram carousel generator.

## Install

1. Upload this `.zip` file directly to Claude as a plugin. Do **not** unzip it first.
2. Type `/` in Cowork and you'll see all nine skills listed.

## What's inside

| Skill | What it does |
|---|---|
| `dashboard-style` | Locks a design system so every HTML output Claude builds you comes out on-brand |
| `find-skills` | Answers "can Claude do this?" by searching your installed skills and the wider marketplace |
| `visual-explainer` | Turns a concept or plan into a self-contained, shareable HTML page |
| `pdf-guide` | Produces a polished, magazine-style PDF guide from any content |
| `skill-dashboard` | Builds a searchable dashboard of every skill you have installed |
| `skills-audit` | Flags duplicate or unused skills with a health score |
| `end-of-day-summary` | A short report of what got done today and what's carrying over |
| `obsidian-daily-note` | Preps tomorrow's Obsidian daily note before you close your laptop |
| `ig-carousel` | Turns a topic or transcript into a cinematic Instagram carousel |
| `customize-test` | A one-time walkthrough that swaps in your name, brand, and colors across all nine skills |

## Requirements

- Claude Cowork (desktop app)
- Some skills (dashboard-style, ig-carousel) run a first-time setup asking for your brand colors and voice

---
NeuraFlow Academy · neuraflow.cloud
