---
name: end-of-day-summary-test
description: Automated end-of-day review with a visual HTML report. Use when the user says "end of day summary", "wrap up my day", "daily wrapup", "what did I do today", or any variation of wanting their day recapped as a shareable HTML report. Scans the current project for file and git activity in the last 24 hours, asks what else happened off-screen, and generates a polished HTML report. Ships with a dark theme by default — override with your brand colors or ask for light mode.
---

# End of Day Summary

Scans your current project for everything that changed today, asks what else you accomplished, and generates a polished HTML report you can review or share.

## Customizing for your brand

Defaults below are a starting point. Override any of it by telling Claude:
- **Colors:** "Use my brand colors — navy #0a2540 and white cards on a cream page"
- **Mode:** "Make it light mode"
- **Fields:** "Skip the hours tracked — I don't track time" or "Add a section for money earned"
- **Scope:** "Also pull my Google Calendar events for today" (requires calendar connector)

If you don't specify, it uses the defaults.

## Workflow

### Step 1: Scan for today's activity

Automatically detect what happened in the last 24 hours inside the current project:

**File changes** (use `find` with relative path `.`):
```bash
find . -type f -not -path './.git/*' -not -path './node_modules/*' -mtime -1
```

**Git activity** (if in a git repo):
```bash
git log --since="24 hours ago" --oneline --all
git diff --stat HEAD~5 HEAD  # fallback if no recent commits
```

**Categorize each item:**
- New files created today
- Existing files modified today
- Files deleted today
- Git commits made today

Present the findings to the user as a quick summary list.

### Step 2: Ask the user

After showing what was detected, ask:

> "Here's what I found from today. **What else did you work on that I might have missed?** Meetings, calls, planning, anything off-screen."

Also ask:

> "**Anything blocked or stuck?** Things you wanted to finish but couldn't."

And:

> "**What are your top 1-3 priorities for tomorrow?**"

### Step 3: Combine and categorize

Merge the auto-detected activity with the user's input into these categories:

| Category | Icon | What goes here |
|----------|------|---------------|
| **Created** | + | New files, new projects, new documents |
| **Updated** | ~ | Modified files, revised content, iterations |
| **Completed** | check | Finished tasks, shipped items, published content |
| **In Progress** | arrow | Started but not finished, ongoing work |
| **Blocked** | x | Stuck items with reason why |
| **Tomorrow** | star | Top priorities for the next day |

### Step 4: Generate HTML report

Build a single self-contained HTML file with this structure:

**Default design (dark theme):**
- Background: `#0f0f10`
- Card background: `#1a1a1d`
- Card border: `#2a2a2d`
- Text primary: `#ffffff`
- Text secondary: `#888888`
- Accent: `#D97757`
- Success: `#34C759`
- Warning: `#FFD60A`
- Blocked: `#FF3B30`
- Font: Inter (Google Fonts) or system sans-serif fallback
- Max width: `800px`, centered
- Border radius: `12px` on cards

Swap any of these if the user asked for different colors, a light mode, or a different font.

**Layout:**

```
HEADER
  - Date (formatted: "Monday, March 24, 2026")
  - "End of Day Summary" title

STATS BAR (horizontal row of stat cards)
  - Items completed (count)
  - Files changed (count)
  - Commits made (count)
  - Hours tracked (if available, otherwise omit)

CREATED section
  - Each item as a card with filename/description
  - Subtle green left border

UPDATED section
  - Each item as a card
  - Subtle blue left border

COMPLETED section
  - Each item as a card with checkmark
  - Subtle green left border

IN PROGRESS section
  - Each item as a card with progress indicator
  - Subtle orange left border

BLOCKED section (only if items exist)
  - Each item as a card with the blocker reason
  - Subtle red left border

TOMORROW section
  - Numbered priority list
  - Accent color numbers

FOOTER
  - Generation timestamp
```

**Requirements:**
- All CSS inline (no external stylesheets)
- Zero external dependencies (except optional Google Font)
- Responsive: readable on mobile
- Subtle fade-in animation on cards (CSS only, no JS required)
- Each section collapses if empty (do not show empty sections)

### Step 5: Save and open

Save the report to: `outputs/daily-summary-YYYY-MM-DD.html` inside the current project.

Create the `outputs/` directory if it does not exist.

Open the file in the default browser:
```bash
open outputs/daily-summary-YYYY-MM-DD.html
```

Share a `computer://` link so the user can click to open it.

## Guardrails

- Never fabricate activity. Only report files and commits that actually exist.
- If the project is not a git repo, skip git-related checks silently. Do not error out.
- Exclude common noise: `.git/`, `node_modules/`, `.DS_Store`, `__pycache__/`, `*.pyc`, lock files.
- Keep descriptions short. One line per item in the report.
- If there is genuinely no activity detected and the user has nothing to add, say so honestly instead of generating an empty report.
- The report should look good enough to screenshot and share. Treat it like a product, not a log dump.
- Always use the current date for the filename. If run after midnight, use the previous day's date if the user says "wrap up my day."
