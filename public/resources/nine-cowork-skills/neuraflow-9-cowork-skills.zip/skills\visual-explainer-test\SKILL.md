---
name: visual-explainer-test
description: Generate a beautiful self-contained HTML page that visually explains a concept, system, architecture, workflow, or strategy. Use when the user says "explain this visually", "visual explainer", "make a diagram page", "explain this to my team", "architecture overview", "how does this work", "visualize this concept", or wants a complex idea turned into a styled page with diagrams, flow, cards, and hierarchy (not a dashboard of metrics — for dashboards/briefings/reports, use dashboard-style instead).
---

# Visual Explainer

Generate beautiful, self-contained HTML pages that visually explain complex concepts, systems, architectures, plans, or workflows. These aren't simple text explanations — they're interactive, styled pages with diagrams, cards, sections, and visual hierarchy that make complex ideas immediately understandable.

## When to Use

- Explaining a system architecture or how tools connect
- Breaking down a business process or workflow
- Visualizing a plan, strategy, or proposal
- Making a concept understandable for a non-technical audience
- Mapping out how a feature, product, or framework works
- Any time "let me draw this out" would help

**When NOT to use:** Dashboards, briefings, stats reports, morning recaps, end-of-day summaries, or anything data-forward — those go through `dashboard-style` instead. Visual explainer is for *concepts*, not *metrics*.

## Process

### Step 1: Understand what needs explaining

- What is the concept, system, or process?
- Who is the audience? (technical team, non-technical stakeholders, clients)
- What level of detail? (high-level overview vs. detailed breakdown)
- Any specific aspects to emphasize?

### Step 2: Choose the right visual components

Pick the best fit for the content:

| Component          | Best for |
| ------------------ | -------- |
| **Flow diagram**   | Processes, pipelines, step-by-step workflows |
| **Card grid**      | Features, categories, team members, tools |
| **Comparison**     | Before/after, options, alternatives |
| **Timeline**       | History, roadmaps, project phases |
| **Hierarchy/tree** | Org charts, system layers, taxonomies |
| **Annotated diagram** | System architecture, how things connect |
| **Accordion sections** | Detailed breakdowns that can expand |

### Step 3: Build the page

Generate a single self-contained HTML file with all CSS and JS inline.

**Design principles**
- Clear visual hierarchy — the most important information stands out
- Color-coded zones to group related concepts
- Adequate whitespace — nothing cramped
- Responsive enough for desktop and tablet
- Interactive where it helps (hover states, expandable sections)

**Default aesthetic (overridable)** — if the user doesn't specify, use a modern editorial dark look:
- Background: `#0a0a0a` with light text
- Typography: system font stack (`-apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif`)
- Headlines: 32–48px, weight 700
- Body: 16–18px, weight 400
- Labels: 12–14px, weight 600, uppercase with letter-spacing
- Primary text: `#f5f5f7`
- Secondary text: `#86868b`
- Accent: `#DA7756` (highlights, active states, key annotations)
- Cards: `rgba(255,255,255,0.04)` with subtle borders

**Swap these freely if the user gives brand colors or asks for light mode.** If they say "use our blue #0052cc and white cards on a light page," do that instead. The defaults are a starting point, not a rule.

### Step 4: Save and share

Save the HTML file and share a `computer://` link so the user can open it.

## Standard page structure

1. **Title section** — what this explains, one-line subtitle
2. **Overview** — high-level summary or a single key stat
3. **Main visual** — the core diagram, flow, or visualization
4. **Detail sections** — deeper breakdowns of each component
5. **Summary or takeaway** — what the viewer should remember

## Rules

- **Self-contained.** One HTML file. No external dependencies.
- **Every section must have a visual component** — never just blocks of text.
- **Understandable in 30 seconds at a glance**, with detail available for those who dig deeper.
- Works in any modern browser. No framework dependencies.
- If the concept has more than 7 components, group them into categories first. Don't overwhelm.
- Use real, specific language. "The API processes 10,000 requests/second" beats "The API is fast."
