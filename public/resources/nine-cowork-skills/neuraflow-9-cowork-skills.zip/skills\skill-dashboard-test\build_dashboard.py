#!/usr/bin/env python3
"""
My Skills Dashboard — Scanner + Generator
------------------------------------------
Scans a Claude Cowork install for all installed skills and slash commands,
categorizes them, and emits a self-contained HTML dashboard.

Usage:
    python3 build_dashboard.py                       # auto-discover, write to ./index.html
    python3 build_dashboard.py --out /path/out.html  # custom output path
    python3 build_dashboard.py --project /path       # also scan a project folder's .claude/
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

HOME = Path.home()


# ---------- YAML frontmatter parser (no dependency) ----------
def parse_frontmatter(text):
    """Extract the top YAML frontmatter block. Returns dict + body."""
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    block = text[3:end].strip()
    body = text[end + 4:].lstrip("\n")
    fm = {}
    current_key = None
    current_list = None
    for raw in block.splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        # list item belongs to the previous key
        if line.lstrip().startswith("- ") and current_list is not None:
            current_list.append(line.lstrip()[2:].strip().strip('"').strip("'"))
            continue
        m = re.match(r"^([A-Za-z0-9_-]+)\s*:\s*(.*)$", line)
        if not m:
            continue
        key, value = m.group(1).strip(), m.group(2).strip()
        if value == "":
            # start of a list or block
            current_key = key
            current_list = []
            fm[key] = current_list
        else:
            # strip quotes
            if (value.startswith('"') and value.endswith('"')) or \
               (value.startswith("'") and value.endswith("'")):
                value = value[1:-1]
            fm[key] = value
            current_key = key
            current_list = None
    return fm, body


# ---------- Categorization ----------
CATEGORY_KEYWORDS = {
    "content":       ["script", "hook", "title", "youtube", "newsletter", "blog", "thread", "caption", "post", "repurpose", "tele", "course", "lesson", "ig", "carousel", "story", "video", "write", "editor"],
    "research":      ["research", "trend", "brief", "intel", "compet", "morning", "news", "scan", "hunt", "resource", "analytics", "audit"],
    "design":        ["thumbnail", "slide", "deck", "graphic", "visual", "diagram", "infographic", "image", "page", "animated", "website", "design", "explainer", "analogy", "pptx"],
    "business":      ["contract", "proposal", "invoice", "sow", "sop", "testimon", "case-stud", "sales", "deal", "client", "agency", "money", "budget", "expense", "receipt", "pricing", "tax"],
    "communication": ["email", "linkedin", "slack", "thank", "difficult", "note", "message", "gmail", "reply", "outreach"],
    "automation":    ["schedule", "webhook", "zapier", "workflow", "auto", "dispatch", "prompter"],
    "productivity":  ["meeting", "habit", "goal", "weekly", "travel", "decision", "learning", "book", "journal", "task", "plan", "focus", "memory"],
    "system":        ["context", "claude.md", "skill-creator", "audit", "weekly-audit", "cowork", "os", "end-of-day", "wrapup", "consolidate", "begin", "setup", "customize", "tour", "ideas"],
    "starter":       ["starter", "tour", "begin", "onboard", "quickstart", "kickstart"],
}

# Categories in display order
CAT_ORDER = ["content", "research", "design", "business", "communication",
             "automation", "productivity", "system", "starter"]

CAT_META = {
    "content":       {"title": "Content Creation",    "icon": "pen"},
    "research":      {"title": "Research & Strategy", "icon": "search"},
    "design":        {"title": "Design & Visuals",    "icon": "palette"},
    "business":      {"title": "Business",            "icon": "briefcase"},
    "communication": {"title": "Communication",       "icon": "chat"},
    "automation":    {"title": "Automation",          "icon": "gear"},
    "productivity":  {"title": "Productivity",        "icon": "rocket"},
    "system":        {"title": "System & Tools",      "icon": "wrench"},
    "starter":       {"title": "Starter & Onboarding","icon": "package"},
}


def categorize(name, description):
    """Score each category by keyword hits in name + description."""
    text = f"{name} {description}".lower()
    scores = {cat: 0 for cat in CATEGORY_KEYWORDS}
    for cat, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                scores[cat] += 1 + (2 if kw in name.lower() else 0)
    best = max(scores.items(), key=lambda kv: kv[1])
    return best[0] if best[1] > 0 else "productivity"


# ---------- Plugin manifest lookup ----------
def load_plugin_manifests():
    """Find all plugin manifests across the Claude install. Returns id->name dict."""
    mapping = {}
    search_roots = [
        HOME / "Library/Application Support/Claude/local-agent-mode-sessions",
        HOME / "Library/Application Support/Claude",
    ]
    for root in search_roots:
        if not root.exists():
            continue
        for manifest in root.rglob("manifest.json"):
            try:
                data = json.loads(manifest.read_text())
                plugins = data.get("plugins", data)
                if isinstance(plugins, dict):
                    for pid, info in plugins.items():
                        if isinstance(info, dict) and "name" in info:
                            mapping[pid] = info["name"]
                elif isinstance(plugins, list):
                    for item in plugins:
                        if isinstance(item, dict):
                            pid = item.get("id") or item.get("plugin_id")
                            name = item.get("name") or item.get("displayName")
                            if pid and name:
                                mapping[pid] = name
            except Exception:
                continue
    return mapping


# ---------- Source discovery ----------
def discover_sources(project_path=None):
    """Return list of (label, root_path, kind) tuples to scan."""
    sources = []

    # User-level skills
    user_skills = HOME / ".claude/skills"
    if user_skills.exists():
        sources.append(("User Skills", user_skills, "user_skills"))

    # User-level commands
    user_commands = HOME / ".claude/commands"
    if user_commands.exists():
        sources.append(("User Commands", user_commands, "user_commands"))

    # Cowork remote plugins (installed)
    sessions_root = HOME / "Library/Application Support/Claude/local-agent-mode-sessions"
    if sessions_root.exists():
        for session_dir in sessions_root.iterdir():
            if not session_dir.is_dir():
                continue
            for subdir in session_dir.iterdir():
                if not subdir.is_dir():
                    continue
                rpm = subdir / "rpm"
                if rpm.exists():
                    for plugin_dir in rpm.iterdir():
                        if plugin_dir.is_dir() and plugin_dir.name.startswith("plugin_"):
                            skills_dir = plugin_dir / "skills"
                            cmds_dir = plugin_dir / "commands"
                            if skills_dir.exists():
                                sources.append((plugin_dir.name, skills_dir, "plugin_skills"))
                            if cmds_dir.exists():
                                sources.append((plugin_dir.name, cmds_dir, "plugin_commands"))

    # Marketplace / cached plugins
    for marketplace_root in [
        HOME / "Library/Application Support/Claude/cowork_plugins/marketplaces",
        HOME / "Library/Application Support/Claude/cowork_plugins/cache",
    ]:
        if marketplace_root.exists():
            for skill_md in marketplace_root.rglob("SKILL.md"):
                # dedup: only add parent "skills" dir once
                skills_dir = skill_md.parent.parent
                if skills_dir.name == "skills":
                    entry = (skills_dir.parent.name, skills_dir, "plugin_skills")
                    if entry not in sources:
                        sources.append(entry)
            for cmd_md in marketplace_root.rglob("commands/*.md"):
                cmds_dir = cmd_md.parent
                entry = (cmds_dir.parent.name, cmds_dir, "plugin_commands")
                if entry not in sources:
                    sources.append(entry)

    # Hostloop / anthropic built-in skills
    hostloop = Path("/var/folders")
    if hostloop.exists():
        for candidate in hostloop.rglob("claude-hostloop-plugins"):
            for skills_dir in candidate.rglob("skills"):
                if skills_dir.is_dir() and skills_dir.parent.name != "skills":
                    entry = ("Anthropic Skills", skills_dir, "builtin_skills")
                    if entry not in sources:
                        sources.append(entry)
                    break
            break  # first match only

    # Project skills + commands
    if project_path:
        project_path = Path(project_path)
        proj_skills = project_path / ".claude/skills"
        proj_cmds = project_path / ".claude/commands"
        if proj_skills.exists():
            sources.append((f"Project: {project_path.name}", proj_skills, "project_skills"))
        if proj_cmds.exists():
            sources.append((f"Project: {project_path.name}", proj_cmds, "project_commands"))

    return sources


# ---------- Scanner ----------
def scan_skill_dir(skills_dir, plugin_label):
    """Walk a /skills dir for SKILL.md files."""
    items = []
    for skill_md in skills_dir.glob("*/SKILL.md"):
        try:
            text = skill_md.read_text(encoding="utf-8", errors="replace")
            fm, _ = parse_frontmatter(text)
            name = fm.get("name") or skill_md.parent.name
            desc = fm.get("description") or ""
            # Clean multi-line descriptions
            desc = re.sub(r"\s+", " ", desc).strip()
            if len(desc) > 400:
                desc = desc[:397] + "..."
            items.append({
                "name": name.replace("-", " ").replace("_", " ").title(),
                "raw_name": name,
                "cmd": f"skill: {skill_md.parent.name}",
                "desc": desc[:160] + ("..." if len(desc) > 160 else ""),
                "long": desc,
                "kind": "skill",
                "source": plugin_label,
                "path": str(skill_md),
            })
        except Exception as e:
            continue
    return items


def scan_commands_dir(cmds_dir, plugin_label):
    """Walk a /commands dir for *.md files."""
    items = []
    for cmd_md in cmds_dir.glob("*.md"):
        if cmd_md.name.startswith("_"):
            continue  # methodology files
        try:
            text = cmd_md.read_text(encoding="utf-8", errors="replace")
            fm, body = parse_frontmatter(text)
            cmd_name = cmd_md.stem
            desc = fm.get("description") or ""
            if not desc:
                # Take the first substantive line
                for line in body.splitlines():
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("<!--"):
                        desc = line
                        break
            desc = re.sub(r"\$ARGUMENTS", "...", desc)
            desc = re.sub(r"\s+", " ", desc).strip()
            if len(desc) > 400:
                desc = desc[:397] + "..."
            items.append({
                "name": cmd_name.replace("-", " ").replace("_", " ").title(),
                "raw_name": cmd_name,
                "cmd": f"/{cmd_name}",
                "desc": desc[:160] + ("..." if len(desc) > 160 else ""),
                "long": desc,
                "kind": "command",
                "source": plugin_label,
                "path": str(cmd_md),
            })
        except Exception:
            continue
    return items


def scan_all(project_path=None):
    sources = discover_sources(project_path)
    plugin_map = load_plugin_manifests()
    all_items = []
    seen = set()
    for label, root, kind in sources:
        friendly = plugin_map.get(label, label.replace("plugin_", "").replace("_", " "))
        if "skills" in kind or "builtin" in kind:
            items = scan_skill_dir(root, friendly)
        elif "commands" in kind:
            items = scan_commands_dir(root, friendly)
        else:
            continue
        for it in items:
            key = (it["raw_name"], it["kind"])
            if key in seen:
                continue
            seen.add(key)
            it["cat"] = categorize(it["raw_name"], it["long"])
            all_items.append(it)
    return all_items


# ---------- HTML template ----------
TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Skills Dashboard — Claude Cowork</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg viewBox='0 0 24 24' fill='%23D97757' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='m4.7144 15.9555 4.7174-2.6471.079-.2307-.079-.1275h-.2307l-.7893-.0486-2.6956-.0729-2.3375-.0971-2.2646-.1214-.5707-.1215-.5343-.7042.0546-.3522.4797-.3218.686.0608 1.5179.1032 2.2767.1578 1.6514.0972 2.4468.255h.3886l.0546-.1579-.1336-.0971-.1032-.0972L6.973 9.8356l-2.55-1.6879-1.3356-.9714-.7225-.4918-.3643-.4614-.1578-1.0078.6557-.7225.8803.0607.2246.0607.8925.686 1.9064 1.4754 2.4893 1.8336.3643.3035.1457-.1032.0182-.0728-.164-.2733-1.3539-2.4467-1.445-2.4893-.6435-1.032-.17-.6194c-.0607-.255-.1032-.4674-.1032-.7285L6.287.1335 6.6997 0l.9957.1336.419.3642.6192 1.4147 1.0018 2.2282 1.5543 3.0296.4553.8985.2429.8318.091.255h.1579v-.1457l.1275-1.706.2368-2.0947.2307-2.6957.0789-.7589.3764-.9107.7468-.4918.5828.2793.4797.686-.0668.4433-.2853 1.8517-.5586 2.9021-.3643 1.9429h.2125l.2429-.2429.9835-1.3053 1.6514-2.0643.7286-.8196.85-.9046.5464-.4311h1.0321l.759 1.1293-.34 1.1657-1.0625 1.3478-.8804 1.1414-1.2628 1.7-.7893 1.36.0729.1093.1882-.0183 2.8535-.607 1.5421-.2794 1.8396-.3157.8318.3886.091.3946-.3278.8075-1.967.4857-2.3072.4614-3.4364.8136-.0425.0304.0486.0607 1.5482.1457.6618.0364h1.621l3.0175.2247.7892.522.4736.6376-.079.4857-1.2142.6193-1.6393-.3886-3.825-.9107-1.3113-.3279h-.1822v.1093l1.0929 1.0686 2.0035 1.8092 2.5075 2.3314.1275.5768-.3218.4554-.34-.0486-2.2039-1.6575-.85-.7468-1.9246-1.621h-.1275v.17l.4432.6496 2.3436 3.5214.1214 1.0807-.17.3521-.6071.2125-.6679-.1214-1.3721-1.9246L14.38 17.959l-1.1414-1.9428-.1397.079-.674 7.2552-.3156.3703-.7286.2793-.6071-.4614-.3218-.7468.3218-1.4753.3886-1.9246.3157-1.53.2853-1.9004.17-.6314-.0121-.0425-.1397.0182-1.4328 1.9672-2.1796 2.9446-1.7243 1.8456-.4128.164-.7164-.3704.0667-.6618.4008-.5889 2.386-3.0357 1.4389-1.882.929-1.0868-.0062-.1579h-.0546l-6.3385 4.1164-1.1293.1457-.4857-.4554.0608-.7467.2307-.2429 1.9064-1.3114Z'/%3E%3C/svg%3E">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Instrument+Serif:ital@0;1&display=swap');
  * { margin: 0; padding: 0; box-sizing: border-box; }
  :root {
    --bg: #1a1714; --bg-2: #211e1a;
    --surface: #faf5ef; --surface-hover: #f5ede4; --surface-dark: #2a2520;
    --border: #e8ddd0; --border-dark: #3a332c;
    --text-dark: #1a1714; --text-light: #f5ede4;
    --text-secondary-light: #a89a8c; --text-muted-light: #6b5f53;
    --text-secondary-dark: #5c4f42;
    --claude: #D97757; --claude-light: #e8956e; --claude-dark: #c4613f;
    --claude-glow: rgba(217, 119, 87, 0.15); --claude-cream: #f7efe7;
    --warm-gold: #c4a265;
  }
  body { font-family: 'Inter', -apple-system, sans-serif; background: var(--bg); color: var(--text-light); overflow-x: hidden; -webkit-font-smoothing: antialiased; }
  .ambient { position: fixed; top: 0; left: 0; right: 0; bottom: 0; pointer-events: none; z-index: 0; overflow: hidden; }
  .ambient-orb { position: absolute; border-radius: 50%; filter: blur(150px); opacity: 0.06; animation: drift 25s ease-in-out infinite; }
  .ambient-orb:nth-child(1) { width: 700px; height: 700px; background: var(--claude); top: -250px; left: -200px; }
  .ambient-orb:nth-child(2) { width: 500px; height: 500px; background: var(--warm-gold); top: 50%; right: -200px; animation-delay: -8s; }
  .ambient-orb:nth-child(3) { width: 400px; height: 400px; background: var(--claude-light); bottom: -150px; left: 40%; animation-delay: -16s; }
  @keyframes drift { 0%, 100% { transform: translate(0,0) scale(1);} 33% { transform: translate(40px,-30px) scale(1.05);} 66% { transform: translate(-30px,25px) scale(.95);} }
  .container { max-width: 1280px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 1; }

  header { padding: 56px 0 0; text-align: center; }
  .claude-logo { display: inline-flex; align-items: center; gap: 12px; margin-bottom: 28px; }
  .claude-sparkle { width: 40px; height: 40px; animation: spin-slow 20s linear infinite; }
  @keyframes spin-slow { to { transform: rotate(360deg); } }
  .claude-logo-text { font-family: 'Instrument Serif', Georgia, serif; font-size: 20px; color: var(--claude); letter-spacing: 0.01em; }
  .badge { display: inline-flex; align-items: center; gap: 8px; padding: 6px 18px; background: var(--claude-glow); border: 1px solid rgba(217,119,87,0.25); border-radius: 100px; font-size: 12px; font-weight: 600; color: var(--claude-light); margin-bottom: 24px; letter-spacing: 0.06em; text-transform: uppercase; }
  .badge-dot { width: 6px; height: 6px; background: var(--claude); border-radius: 50%; animation: pulse-dot 2s ease-in-out infinite; }
  @keyframes pulse-dot { 0%,100%{opacity:1;} 50%{opacity:.3;} }

  h1 { font-family: 'Instrument Serif', Georgia, serif; font-size: clamp(38px, 5.5vw, 72px); font-weight: 400; letter-spacing: -0.02em; line-height: 1.05; margin-bottom: 20px; color: var(--text-light); }
  h1 em { font-style: italic; color: var(--claude); }
  .subtitle { font-size: 17px; color: var(--text-secondary-light); max-width: 620px; margin: 0 auto 36px; line-height: 1.65; }

  .stats-bar { display: flex; justify-content: center; gap: 40px; padding: 24px 0 44px; flex-wrap: wrap; }
  .stat-item { text-align: center; }
  .stat-num { font-family: 'Instrument Serif', Georgia, serif; font-size: 36px; font-weight: 400; color: var(--claude); }
  .stat-label { font-size: 11px; color: var(--text-muted-light); font-weight: 600; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.08em; }

  .divider { width: 60px; height: 1px; background: var(--border-dark); margin: 0 auto 48px; }

  .controls { display: flex; flex-direction: column; align-items: center; gap: 16px; margin-bottom: 48px; }
  .search-wrap { position: relative; width: 100%; max-width: 520px; }
  .search-wrap svg { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-muted-light); width: 18px; height: 18px; }
  .search-input { width: 100%; padding: 14px 16px 14px 44px; background: var(--surface-dark); border: 1px solid var(--border-dark); border-radius: 12px; color: var(--text-light); font-size: 15px; font-family: inherit; outline: none; transition: all 0.2s; }
  .search-input::placeholder { color: var(--text-muted-light); }
  .search-input:focus { border-color: var(--claude); box-shadow: 0 0 0 3px var(--claude-glow); }

  .filter-pills { display: flex; gap: 6px; flex-wrap: wrap; justify-content: center; }
  .pill { padding: 7px 16px; border-radius: 100px; font-size: 12px; font-weight: 600; border: 1px solid var(--border-dark); background: transparent; color: var(--text-muted-light); cursor: pointer; transition: all 0.2s; white-space: nowrap; }
  .pill:hover { border-color: var(--claude); color: var(--claude-light); background: var(--claude-glow); }
  .pill.active { background: var(--claude); color: #fff; border-color: var(--claude); }

  .category-section { margin-bottom: 52px; }
  .category-header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border-dark); }
  .category-icon-wrap { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; background: var(--claude-glow); }
  .category-title { font-family: 'Instrument Serif', Georgia, serif; font-size: 22px; font-weight: 400; }
  .category-count { font-size: 11px; color: var(--text-muted-light); font-weight: 600; background: var(--surface-dark); padding: 3px 10px; border-radius: 100px; margin-left: auto; }

  .skill-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 10px; }
  .skill-card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 20px; cursor: pointer; transition: all 0.25s cubic-bezier(0.4,0,0.2,1); position: relative; overflow: hidden; color: var(--text-dark); }
  .skill-card:hover { background: var(--surface-hover); transform: translateY(-3px); box-shadow: 0 12px 40px rgba(0,0,0,0.25), 0 0 0 1px rgba(217,119,87,0.15); }
  .card-top { display: flex; align-items: flex-start; gap: 14px; margin-bottom: 10px; }
  .card-icon { width: 44px; height: 44px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
  .card-icon svg { width: 36px; height: 36px; }
  .card-info { flex: 1; min-width: 0; }
  .card-name { font-size: 15px; font-weight: 700; letter-spacing: -0.01em; margin-bottom: 2px; color: var(--text-dark); }
  .card-command { font-size: 12px; font-family: 'SF Mono', 'Fira Code', monospace; color: var(--claude-dark); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .card-desc { font-size: 13px; color: var(--text-secondary-dark); line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .card-bottom { display: flex; align-items: center; justify-content: space-between; margin-top: 14px; padding-top: 10px; border-top: 1px solid rgba(0,0,0,0.06); gap: 8px; }
  .card-source { font-size: 10px; color: var(--text-muted-light); font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; }
  .card-tag { font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 6px; text-transform: uppercase; letter-spacing: 0.05em; flex-shrink: 0; }
  .type-command { background: #e8ddd0; color: #6b5f53; }
  .type-skill { background: rgba(217,119,87,0.15); color: var(--claude-dark); }

  .modal-overlay { position: fixed; inset: 0; z-index: 100; background: rgba(10,9,8,0.75); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; padding: 24px; opacity: 0; pointer-events: none; transition: opacity 0.2s ease; }
  .modal-overlay.open { opacity: 1; pointer-events: all; }
  .modal { background: var(--surface); border: 1px solid var(--border); border-radius: 20px; max-width: 620px; width: 100%; padding: 32px; color: var(--text-dark); position: relative; transform: translateY(12px) scale(0.97); transition: transform 0.25s cubic-bezier(0.4,0,0.2,1); max-height: 85vh; overflow-y: auto; }
  .modal-overlay.open .modal { transform: translateY(0) scale(1); }
  .modal-close { position: absolute; top: 16px; right: 16px; width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border); background: var(--surface); cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--text-secondary-dark); transition: all 0.15s; }
  .modal-close:hover { background: var(--surface-hover); color: var(--text-dark); }
  .modal-close svg { width: 16px; height: 16px; }
  .modal-header { display: flex; align-items: center; gap: 16px; margin-bottom: 20px; padding-right: 40px; }
  .modal-icon { width: 48px; height: 48px; flex-shrink: 0; }
  .modal-icon svg { width: 42px; height: 42px; }
  .modal-title { font-size: 22px; font-weight: 700; letter-spacing: -0.01em; }
  .modal-cmd { font-size: 13px; font-family: 'SF Mono', monospace; color: var(--claude-dark); font-weight: 500; margin-top: 2px; }
  .modal-divider { height: 1px; background: var(--border); margin: 0 0 20px; }
  .modal-section-label { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted-light); margin-bottom: 8px; }
  .modal-desc { font-size: 15px; line-height: 1.7; color: var(--text-secondary-dark); margin-bottom: 20px; white-space: pre-wrap; }
  .modal-source { font-size: 12px; font-family: 'SF Mono', monospace; color: var(--text-muted-light); background: var(--surface-hover); padding: 10px 12px; border-radius: 8px; margin-bottom: 16px; word-break: break-all; }
  .modal-trigger-box { background: var(--claude-glow); border: 1px solid rgba(217,119,87,0.25); padding: 14px 16px; border-radius: 10px; margin-bottom: 20px; }
  .modal-trigger-box strong { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--claude-dark); margin-bottom: 6px; font-weight: 700; }
  .modal-trigger-box span { font-size: 14px; color: var(--text-dark); }
  .modal-tag-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }


  footer { text-align: center; padding: 32px 0; border-top: 1px solid var(--border-dark); color: var(--text-muted-light); font-size: 12px; letter-spacing: 0.02em; }
  footer a { color: var(--claude); text-decoration: none; }

  .no-results { text-align: center; padding: 64px 24px; color: var(--text-muted-light); font-size: 15px; display: none; }
  .fade-in { opacity: 0; transform: translateY(12px); animation: fadeUp 0.4s ease forwards; }
  @keyframes fadeUp { to { opacity: 1; transform: translateY(0);} }

  @media (max-width: 640px) {
    .stats-bar { gap: 20px; }
    .skill-grid { grid-template-columns: 1fr; }
    .filter-pills { justify-content: flex-start; overflow-x: auto; flex-wrap: nowrap; padding-bottom: 8px; -webkit-overflow-scrolling: touch; }
    header { padding: 32px 0 0; }
  }

  /* ------- Audit panel ------- */
  .audit-wrap { margin: 0 0 40px; }
  .audit-card { background: var(--card-bg); border: 1px solid var(--border-dark); border-radius: 20px; padding: 32px; display: grid; grid-template-columns: auto 1fr; gap: 36px; align-items: start; position: relative; overflow: hidden; }
  .audit-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, transparent, var(--audit-color, var(--claude)), transparent); }
  .audit-score-wrap { display: flex; flex-direction: column; align-items: center; min-width: 150px; }
  .audit-score-ring { width: 132px; height: 132px; position: relative; display: grid; place-items: center; }
  .audit-score-ring svg { position: absolute; inset: 0; width: 100%; height: 100%; transform: rotate(-90deg); }
  .audit-score-track { fill: none; stroke: var(--border-dark); stroke-width: 10; }
  .audit-score-arc { fill: none; stroke: var(--audit-color, var(--claude)); stroke-width: 10; stroke-linecap: round; transition: stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1); }
  .audit-score-num { font-family: 'Instrument Serif', Georgia, serif; font-size: 48px; color: var(--audit-color, var(--claude)); line-height: 1; }
  .audit-score-label { font-size: 10px; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: var(--audit-color, var(--claude)); margin-top: 8px; }
  .audit-body { min-width: 0; }
  .audit-header { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
  .audit-kicker { font-size: 11px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: var(--text-muted-light); }
  .audit-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--audit-color, var(--claude)); animation: pulse-dot 2s ease-in-out infinite; }
  .audit-title { font-family: 'Instrument Serif', Georgia, serif; font-size: 30px; color: var(--text-light); margin: 0 0 6px; letter-spacing: -0.01em; }
  .audit-subtitle { font-size: 14px; color: var(--text-muted-light); margin: 0 0 20px; }
  .audit-summary { display: flex; gap: 28px; margin-bottom: 22px; flex-wrap: wrap; }
  .audit-metric { display: flex; flex-direction: column; gap: 2px; }
  .audit-metric-num { font-family: 'Instrument Serif', Georgia, serif; font-size: 26px; color: var(--text-light); line-height: 1; }
  .audit-metric-label { font-size: 10px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted-light); }
  .audit-recs { display: flex; flex-direction: column; gap: 10px; }
  .audit-rec { display: flex; align-items: flex-start; gap: 14px; padding: 14px 16px; background: rgba(255,255,255,0.02); border: 1px solid var(--border-dark); border-radius: 12px; }
  .audit-rec-pri { font-size: 9px; font-weight: 800; letter-spacing: 0.1em; text-transform: uppercase; padding: 4px 8px; border-radius: 6px; flex-shrink: 0; line-height: 1; margin-top: 2px; }
  .audit-rec-pri.high { background: rgba(239,68,68,0.12); color: #f87171; }
  .audit-rec-pri.medium { background: rgba(245,158,11,0.12); color: #fbbf24; }
  .audit-rec-pri.low { background: rgba(132,204,22,0.1); color: #a3e635; }
  .audit-rec-body { min-width: 0; }
  .audit-rec-title { font-size: 14px; font-weight: 600; color: var(--text-light); margin-bottom: 2px; }
  .audit-rec-detail { font-size: 12px; color: var(--text-muted-light); }
  .audit-empty { font-size: 13px; color: var(--text-muted-light); padding: 18px; background: rgba(34,197,94,0.05); border: 1px dashed rgba(34,197,94,0.2); border-radius: 10px; color: #86efac; }
  @media (max-width: 720px) {
    .audit-card { grid-template-columns: 1fr; gap: 24px; padding: 24px; }
    .audit-score-wrap { flex-direction: row; gap: 20px; justify-content: flex-start; }
  }
</style>
</head>
<body>

<div class="ambient">
  <div class="ambient-orb"></div>
  <div class="ambient-orb"></div>
  <div class="ambient-orb"></div>
</div>

<header>
  <div class="container">
    <div class="claude-logo">
      <svg class="claude-sparkle" viewBox="0 0 24 24" fill="#D97757" xmlns="http://www.w3.org/2000/svg"><path d="__STARBURST_PATH__"/></svg>
      <span class="claude-logo-text">Claude Cowork</span>
    </div>
    <br>
    <div class="badge"><div class="badge-dot"></div>Refreshed __REFRESH_DATE__</div>
    <h1>My <em>Skills</em> Dashboard</h1>
    <p class="subtitle">Every skill and slash command installed on your Claude Cowork setup, in one place. Search, filter, or click any card to see how to trigger it.</p>

    <div class="stats-bar">
      <div class="stat-item"><div class="stat-num">__TOTAL__</div><div class="stat-label">Total</div></div>
      <div class="stat-item"><div class="stat-num">__SKILLS_COUNT__</div><div class="stat-label">Skills</div></div>
      <div class="stat-item"><div class="stat-num">__COMMANDS_COUNT__</div><div class="stat-label">Commands</div></div>
      <div class="stat-item"><div class="stat-num">__CATEGORIES__</div><div class="stat-label">Categories</div></div>
    </div>
    <div class="divider"></div>
  </div>
</header>

<main>
  <div class="container">
    __AUDIT_SECTION__
    <div class="controls">
      <div class="search-wrap">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"/></svg>
        <input type="text" class="search-input" placeholder="Search skills, commands, descriptions..." id="searchInput">
      </div>
      <div class="filter-pills" id="filterPills">
        __FILTER_PILLS__
      </div>
    </div>

    <div id="skillSections"></div>
    <div class="no-results" id="noResults"><p>No skills match your search.</p></div>
  </div>
</main>

<footer>
  <div class="container">
    Auto-refreshed by your weekly scheduled task
  </div>
</footer>

<div class="modal-overlay" id="modalOverlay">
  <div class="modal" id="modal">
    <button class="modal-close" id="modalClose">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"/></svg>
    </button>
    <div id="modalContent"></div>
  </div>
</div>

<script>
const STARBURST = `<svg viewBox="0 0 24 24" fill="#D97757" xmlns="http://www.w3.org/2000/svg"><path d="__STARBURST_PATH__"/></svg>`;
const SKILLS_DATA = __SKILLS_JSON__;
const CATEGORIES = __CATEGORIES_JSON__;
const CAT_ICONS = __CAT_ICONS_JSON__;
const TAG_CLASSES = { command: "type-command", skill: "type-skill" };
const CAT_ORDER = __CAT_ORDER_JSON__;

function renderSections(filter, query) {
  const container = document.getElementById("skillSections");
  const noResults = document.getElementById("noResults");
  container.innerHTML = "";
  let totalVisible = 0;
  CAT_ORDER.forEach(catKey => {
    if (filter !== "all" && filter !== catKey) return;
    const catInfo = CATEGORIES[catKey];
    if (!catInfo) return;
    let items = SKILLS_DATA.filter(s => s.cat === catKey);
    if (query) {
      const q = query.toLowerCase();
      items = items.filter(s =>
        s.name.toLowerCase().includes(q) ||
        (s.desc||"").toLowerCase().includes(q) ||
        (s.long||"").toLowerCase().includes(q) ||
        s.cmd.toLowerCase().includes(q) ||
        (s.source||"").toLowerCase().includes(q)
      );
    }
    if (!items.length) return;
    totalVisible += items.length;
    const section = document.createElement("div");
    section.className = "category-section fade-in";
    section.innerHTML = `
      <div class="category-header">
        <div class="category-icon-wrap">${CAT_ICONS[catInfo.icon]}</div>
        <div class="category-title">${catInfo.title}</div>
        <div class="category-count">${items.length}</div>
      </div>
      <div class="skill-grid">
        ${items.map(s => `
          <div class="skill-card" data-idx="${SKILLS_DATA.indexOf(s)}">
            <div class="card-top">
              <div class="card-icon">${STARBURST}</div>
              <div class="card-info">
                <div class="card-name">${escapeHtml(s.name)}</div>
                <div class="card-command">${escapeHtml(s.cmd)}</div>
              </div>
            </div>
            <div class="card-desc">${escapeHtml(s.desc||"No description available.")}</div>
            <div class="card-bottom">
              <span class="card-source" title="${escapeHtml(s.source||'')}">${escapeHtml(s.source||'Unknown source')}</span>
              <span class="card-tag ${TAG_CLASSES[s.kind] || ''}">${s.kind}</span>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    container.appendChild(section);
  });
  noResults.style.display = totalVisible === 0 ? "block" : "none";
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

document.getElementById("filterPills").addEventListener("click", e => {
  const pill = e.target.closest(".pill");
  if (!pill) return;
  document.querySelectorAll(".pill").forEach(p => p.classList.remove("active"));
  pill.classList.add("active");
  renderSections(pill.dataset.filter, document.getElementById("searchInput").value);
});

let debounce;
document.getElementById("searchInput").addEventListener("input", e => {
  clearTimeout(debounce);
  debounce = setTimeout(() => {
    const activePill = document.querySelector(".pill.active");
    renderSections(activePill?.dataset.filter || "all", e.target.value);
  }, 150);
});

const overlay = document.getElementById("modalOverlay");
const modalContent = document.getElementById("modalContent");

function openModal(skill) {
  const triggerLabel = skill.kind === 'command' ? 'Type this to trigger' : 'Tell Claude';
  const triggerValue = skill.kind === 'command' ? skill.cmd : `"use the ${skill.raw_name} skill"`;
  modalContent.innerHTML = `
    <div class="modal-header">
      <div class="modal-icon">${STARBURST}</div>
      <div>
        <div class="modal-title">${escapeHtml(skill.name)}</div>
        <div class="modal-cmd">${escapeHtml(skill.cmd)}</div>
      </div>
    </div>
    <div class="modal-divider"></div>
    <div class="modal-trigger-box">
      <strong>${triggerLabel}</strong>
      <span>${escapeHtml(triggerValue)}</span>
    </div>
    <div class="modal-section-label">What it does</div>
    <div class="modal-desc">${escapeHtml(skill.long || skill.desc || 'No description available.')}</div>
    <div class="modal-section-label">Source</div>
    <div class="modal-source">${escapeHtml(skill.source||'Unknown')}${skill.path ? '<br>' + escapeHtml(skill.path) : ''}</div>
    <div class="modal-tag-row">
      <span class="card-tag ${TAG_CLASSES[skill.kind] || ''}">${skill.kind}</span>
      <span class="card-tag" style="background:var(--surface-hover);color:var(--text-secondary-dark)">${escapeHtml(CATEGORIES[skill.cat]?.title||skill.cat)}</span>
    </div>
  `;
  overlay.classList.add("open");
}

overlay.addEventListener("click", e => { if (e.target === overlay) overlay.classList.remove("open"); });
document.getElementById("modalClose").addEventListener("click", () => overlay.classList.remove("open"));
document.addEventListener("keydown", e => { if (e.key === "Escape") overlay.classList.remove("open"); });

document.getElementById("skillSections").addEventListener("click", e => {
  const card = e.target.closest(".skill-card");
  if (!card) return;
  const idx = parseInt(card.dataset.idx, 10);
  if (!isNaN(idx)) openModal(SKILLS_DATA[idx]);
});

renderSections("all", "");
</script>
</body>
</html>
"""

STARBURST_PATH = "m4.7144 15.9555 4.7174-2.6471.079-.2307-.079-.1275h-.2307l-.7893-.0486-2.6956-.0729-2.3375-.0971-2.2646-.1214-.5707-.1215-.5343-.7042.0546-.3522.4797-.3218.686.0608 1.5179.1032 2.2767.1578 1.6514.0972 2.4468.255h.3886l.0546-.1579-.1336-.0971-.1032-.0972L6.973 9.8356l-2.55-1.6879-1.3356-.9714-.7225-.4918-.3643-.4614-.1578-1.0078.6557-.7225.8803.0607.2246.0607.8925.686 1.9064 1.4754 2.4893 1.8336.3643.3035.1457-.1032.0182-.0728-.164-.2733-1.3539-2.4467-1.445-2.4893-.6435-1.032-.17-.6194c-.0607-.255-.1032-.4674-.1032-.7285L6.287.1335 6.6997 0l.9957.1336.419.3642.6192 1.4147 1.0018 2.2282 1.5543 3.0296.4553.8985.2429.8318.091.255h.1579v-.1457l.1275-1.706.2368-2.0947.2307-2.6957.0789-.7589.3764-.9107.7468-.4918.5828.2793.4797.686-.0668.4433-.2853 1.8517-.5586 2.9021-.3643 1.9429h.2125l.2429-.2429.9835-1.3053 1.6514-2.0643.7286-.8196.85-.9046.5464-.4311h1.0321l.759 1.1293-.34 1.1657-1.0625 1.3478-.8804 1.1414-1.2628 1.7-.7893 1.36.0729.1093.1882-.0183 2.8535-.607 1.5421-.2794 1.8396-.3157.8318.3886.091.3946-.3278.8075-1.967.4857-2.3072.4614-3.4364.8136-.0425.0304.0486.0607 1.5482.1457.6618.0364h1.621l3.0175.2247.7892.522.4736.6376-.079.4857-1.2142.6193-1.6393-.3886-3.825-.9107-1.3113-.3279h-.1822v.1093l1.0929 1.0686 2.0035 1.8092 2.5075 2.3314.1275.5768-.3218.4554-.34-.0486-2.2039-1.6575-.85-.7468-1.9246-1.621h-.1275v.17l.4432.6496 2.3436 3.5214.1214 1.0807-.17.3521-.6071.2125-.6679-.1214-1.3721-1.9246L14.38 17.959l-1.1414-1.9428-.1397.079-.674 7.2552-.3156.3703-.7286.2793-.6071-.4614-.3218-.7468.3218-1.4753.3886-1.9246.3157-1.53.2853-1.9004.17-.6314-.0121-.0425-.1397.0182-1.4328 1.9672-2.1796 2.9446-1.7243 1.8456-.4128.164-.7164-.3704.0667-.6618.4008-.5889 2.386-3.0357 1.4389-1.882.929-1.0868-.0062-.1579h-.0546l-6.3385 4.1164-1.1293.1457-.4857-.4554.0608-.7467.2307-.2429 1.9064-1.3114Z"

CAT_ICONS = {
    "pen":       '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><path d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Z"/></svg>',
    "search":    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
    "palette":   '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><circle cx="13.5" cy="6.5" r=".5" fill="#D97757"/><circle cx="17.5" cy="10.5" r=".5" fill="#D97757"/><circle cx="8.5" cy="7.5" r=".5" fill="#D97757"/><circle cx="6.5" cy="12.5" r=".5" fill="#D97757"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2Z"/></svg>',
    "briefcase": '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><rect width="20" height="14" x="2" y="7" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
    "chat":      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    "gear":      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/></svg>',
    "rocket":    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09Z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2Z"/></svg>',
    "wrench":    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76Z"/></svg>',
    "package":   '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97757" stroke-width="2" stroke-linecap="round"><path d="m16.5 9.4-9-5.19"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" x2="12" y1="22.08" y2="12"/></svg>',
}


def render_audit_section(audit):
    """Render the audit panel HTML from an audit.json dict. Returns '' if no audit data."""
    if not audit or not isinstance(audit, dict):
        return ""
    score = audit.get("health", {}).get("score", 0)
    label = audit.get("health", {}).get("label", "")
    color = audit.get("health", {}).get("color", "#D97757")
    summary = audit.get("summary", {})
    recs = audit.get("recommendations", [])
    generated = audit.get("generated_at", "")
    # short date for display
    gen_display = ""
    if generated:
        try:
            gen_display = datetime.fromisoformat(generated).strftime("%b %d")
        except Exception:
            gen_display = generated[:10]

    # Arc math for the score ring
    radius = 58
    circumference = 2 * 3.14159265 * radius
    dash_offset = circumference * (1 - score / 100)

    recs_html = ""
    if recs:
        for r in recs:
            pri = r.get("priority", "low")
            recs_html += f'''
        <div class="audit-rec">
          <div class="audit-rec-pri {pri}">{pri}</div>
          <div class="audit-rec-body">
            <div class="audit-rec-title">{_esc(r.get("title",""))}</div>
            <div class="audit-rec-detail">{_esc(r.get("detail",""))}</div>
          </div>
        </div>'''
    else:
        recs_html = '<div class="audit-empty">Everything looks clean. No cleanup needed right now.</div>'

    metrics = [
        ("Duplicates", summary.get("duplicates", 0)),
        ("Overlaps",   summary.get("overlaps", 0)),
        ("Bootstrap",  summary.get("bootstrap", 0)),
        ("Broken",     summary.get("broken", 0)),
    ]
    metrics_html = "".join(
        f'<div class="audit-metric"><div class="audit-metric-num">{v}</div><div class="audit-metric-label">{k}</div></div>'
        for k, v in metrics
    )

    return f'''
    <div class="audit-wrap">
      <div class="audit-card" style="--audit-color: {color};">
        <div class="audit-score-wrap">
          <div class="audit-score-ring">
            <svg viewBox="0 0 132 132">
              <circle class="audit-score-track" cx="66" cy="66" r="{radius}"></circle>
              <circle class="audit-score-arc" cx="66" cy="66" r="{radius}"
                      stroke-dasharray="{circumference:.2f}"
                      stroke-dashoffset="{dash_offset:.2f}"></circle>
            </svg>
            <div class="audit-score-num">{score}</div>
          </div>
          <div class="audit-score-label">{_esc(label)}</div>
        </div>
        <div class="audit-body">
          <div class="audit-header">
            <div class="audit-dot"></div>
            <div class="audit-kicker">System Audit{f" &middot; {gen_display}" if gen_display else ""}</div>
          </div>
          <h2 class="audit-title">Your system is <em>{_esc(label.lower())}</em></h2>
          <p class="audit-subtitle">What the skills-audit skill flagged this week.</p>
          <div class="audit-summary">{metrics_html}</div>
          <div class="audit-recs">{recs_html}</div>
        </div>
      </div>
    </div>'''


def _esc(s):
    import html as _html
    return _html.escape(str(s)) if s is not None else ""


def build_html(items, refresh_date, audit=None):
    used_cats = sorted({it["cat"] for it in items}, key=lambda c: CAT_ORDER.index(c) if c in CAT_ORDER else 999)
    cats_dict = {c: CAT_META[c] for c in CAT_ORDER if c in CAT_META}

    pills = ['<button class="pill active" data-filter="all">All</button>']
    for c in used_cats:
        if c in CAT_META:
            pills.append(f'<button class="pill" data-filter="{c}">{CAT_META[c]["title"]}</button>')

    skills_count = sum(1 for it in items if it["kind"] == "skill")
    commands_count = sum(1 for it in items if it["kind"] == "command")

    html = TEMPLATE
    html = html.replace("__STARBURST_PATH__", STARBURST_PATH)
    html = html.replace("__REFRESH_DATE__", refresh_date)
    html = html.replace("__TOTAL__", str(len(items)))
    html = html.replace("__SKILLS_COUNT__", str(skills_count))
    html = html.replace("__COMMANDS_COUNT__", str(commands_count))
    html = html.replace("__CATEGORIES__", str(len(used_cats)))
    html = html.replace("__FILTER_PILLS__", "\n        ".join(pills))
    html = html.replace("__SKILLS_JSON__", json.dumps(items, ensure_ascii=False))
    html = html.replace("__CATEGORIES_JSON__", json.dumps(cats_dict, ensure_ascii=False))
    html = html.replace("__CAT_ICONS_JSON__", json.dumps(CAT_ICONS, ensure_ascii=False))
    html = html.replace("__CAT_ORDER_JSON__", json.dumps(used_cats, ensure_ascii=False))
    html = html.replace("__AUDIT_SECTION__", render_audit_section(audit))
    return html


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None, help="Output HTML path")
    ap.add_argument("--project", default=None, help="Project folder to also scan")
    ap.add_argument("--json", action="store_true", help="Emit JSON data alongside HTML")
    args = ap.parse_args()

    out_path = args.out or str(Path(__file__).parent / "index.html")

    print("[scan] Discovering skills and commands...")
    items = scan_all(project_path=args.project)
    print(f"[scan] Found {len(items)} total items.")
    # Sort alphabetically within categories
    items.sort(key=lambda x: (CAT_ORDER.index(x["cat"]) if x["cat"] in CAT_ORDER else 999, x["name"].lower()))

    refresh_date = datetime.now().strftime("%b %d, %Y")

    # Load audit.json if it exists alongside the output HTML (produced by skills-audit)
    audit = None
    audit_path = Path(out_path).parent / "audit.json"
    if audit_path.exists():
        try:
            audit = json.loads(audit_path.read_text(encoding="utf-8"))
            print(f"[audit] Loaded audit data from: {audit_path}")
        except Exception as e:
            print(f"[audit] Failed to parse {audit_path}: {e}")

    html = build_html(items, refresh_date, audit=audit)

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(html, encoding="utf-8")
    print(f"[done] Dashboard written to: {out_path}")

    if args.json:
        json_path = Path(out_path).with_suffix(".json")
        json_path.write_text(json.dumps(items, indent=2), encoding="utf-8")
        print(f"[done] JSON data written to: {json_path}")


if __name__ == "__main__":
    main()
