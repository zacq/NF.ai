---
name: skills-audit-test
description: Audit your Claude Cowork system. Reads your skill-dashboard index, finds duplicate skills, overlapping tools, broken pointers, and bootstrap-only setup skills you can safely uninstall. Writes audit.json so the skill-dashboard renders the findings as a panel at the top with a 0-100 health score and the top 3-5 actions to take this week. Use when the user says "audit my skills", "audit my system", "what should I clean up", "skills audit", "system audit", "find duplicate skills", "what skills overlap", or "what can I uninstall".
---

# skills-audit

A companion to the `skill-dashboard` skill. The dashboard catalogs every skill you have. This audits that catalog and tells you what to clean up.

## What it produces

A JSON file at `skill-dashboard/audit.json` that the dashboard automatically picks up and renders as a panel at the top with:

- **Health score (0-100)** — one hero metric so you can tell at a glance whether your system is clean or bloated
- **Summary counts** — duplicates, overlaps, bootstrap-only, broken
- **Top 3-5 recommendations** — ranked by priority (high/medium/low)

## Audit checks

1. **Duplicates** — same skill name installed by multiple plugins (e.g. `receipt-scanner` from 4 different sources)
2. **Overlaps** — multiple skills doing the same job, grouped by purpose (slideshows, research, briefings, etc.)
3. **Bootstrap** — setup-only skills (`begin`, `tour`, `reset`, `customize`) that are safe to uninstall once you're configured
4. **Broken** — SKILL.md or command files that no longer exist on disk

## How to run

Run `audit.py` from this skill's folder, pointing it at your `skill-dashboard` index:

```bash
python3 /path/to/skills-audit/audit.py \
  --in  /path/to/skill-dashboard/index.json \
  --out /path/to/skill-dashboard/audit.json
```

Then re-run the dashboard build so the new audit data is embedded:

```bash
python3 /path/to/skill-dashboard/build_dashboard.py \
  --project /path/to/your/project \
  --out /path/to/skill-dashboard/index.html \
  --json
```

The combined HTML is at `skill-dashboard/index.html` — open it in your browser.

## Refresh schedule

Best paired with a scheduled task that rebuilds the `skill-dashboard` weekly. The dashboard rebuild always picks up the freshest audit JSON, so run `audit.py` right before the dashboard build.

## Customizing the audit

Edit `audit.py`:

- `OVERLAP_GROUPS` — add or remove keyword clusters that define what counts as overlapping skills
- `BOOTSTRAP_TOKENS` — add slug tokens that should be treated as setup-only
- `compute_health()` — adjust the penalty weights for each finding type
