---
name: customize-test
description: On-demand editor for the 9 Skills Plugin. Run this any time you want to change one thing about one skill (the color on dashboards, the name on PDFs, your Instagram handle on carousels, the vault path for daily notes, etc.). Asks which skill to change, asks what to change, then edits that skill's SKILL.md directly. Trigger words include "customize", "customize this skill", "change the skill", "edit this skill", "tweak the skill", "make it mine", "swap out", "personalize the skill", "this isn't right, fix it", "change the color", "change the name", "update my handle", "customize the 9 skills".
---

# Customize a Skill in the 9 Skills Plugin

This is the on-demand editor. Someone runs one of the 9 skills (dashboard-style, pdf-guide, ig-carousel, etc.), doesn't like one thing about the output, and wants to change it so it stays changed. This skill helps them do that.

It is NOT a big setup interview. It is a one-thing-at-a-time fix.

## When to run this

- After they run a skill and don't like something ("the PDF says the wrong name, I want it to say mine")
- When they explicitly ask ("customize the ig-carousel", "change the dashboard color")
- When something is off and they want it fixed for next time

Do NOT run this as part of plugin installation. The defaults should work out of the box for most people. This is only for when something specific needs to change.

## Tone

Casual. Friendly. One question at a time. No emdashes (hard rule). Short sentences. Treat them like a friend, not a form.

## The flow

### Step 1: Figure out what they want to change

If they already told you ("change the color on dashboards to blue"), skip ahead. You have enough.

If they just said "customize" with no detail, ask:

> "What do you want to change? You can tell me the skill (like 'the PDF one' or 'the carousel') and what about it (color, name, Instagram handle, etc.), or just describe what's bugging you and I'll figure out which skill owns it."

Wait for their answer. If they're vague, ask one clarifying question. Never three.

### Step 2: Map their request to a skill

Here are the 9 skills and what each one owns. When the user describes a problem, match it to the skill that produces that output.

| Skill | What it makes | Common things to customize |
|---|---|---|
| `dashboard-style-test` | HTML dashboards, briefings, reports | Colors (background, accent, surface), font pairing, vibe (warm dark vs clean light) |
| `pdf-guide-test` | Editorial PDFs, cheat sheets, walkthroughs | Author name, publication name, cover palette, byline |
| `ig-carousel-test` | Instagram carousel posts | Instagram handle, CTA line on final slide, accent color |
| `visual-explainer-test` | Explainer HTML pages | Colors, fonts, layout preferences |
| `skill-dashboard-test` | Personal skill inventory dashboard | Dashboard colors, section order, grouping |
| `skills-audit-test` | Audit report of installed skills | Tone of recommendations, what counts as "duplicate" |
| `end-of-day-summary-test` | End-of-day HTML review | Tracked items (what they measure daily), report colors |
| `obsidian-daily-note-test` | Tomorrow's daily note in Obsidian | Vault path, note template, what sections to include |
| `find-skills-test` | Skill discovery helper | Rarely needs customization, but could be source preferences |

If their request clearly maps to one skill, name it back to them: "Got it, that's in the pdf-guide-test skill. I'll update that one."

If it's ambiguous (e.g., "change the color" could be any of 5 skills), ask: "Which skill's color? The dashboards, the PDFs, the carousels, the explainer pages, or the end-of-day summaries?"

### Step 3: Find the skill file

The 9 Skills Plugin lives in the user's Cowork plugins folder. The skill files are at:

```
~/.../9-skills-plugin/skills/[skill-name]/SKILL.md
```

Or inside the installed plugin location. Use the Read tool to open the skill file for the skill they want to change.

If you can't find it, ask: "Where did you install the 9 Skills Plugin? I need to open the SKILL.md to edit it." Don't guess the path.

### Step 4: Make the edit

Read the SKILL.md. Find the section that controls the thing they want to change.

Most common edits and where they live:

- **Colors:** Usually in a "Design System" or "Palette" section near the top of the skill. Look for hex codes like `#d97757` or `#0a0a0a`.
- **Names and handles:** Usually hardcoded in example text or template defaults. Search for any name, handle, or brand string that isn't the current user's.
- **Vault paths:** Look for absolute paths like `/Users/<name>/...`
- **CTAs and copy:** In example outputs or closing sections.
- **Tracked items:** For end-of-day-summary, look for the list of daily metrics.

Use the Edit tool to change exactly what they asked for. Don't restructure the skill. Don't rewrite sections. Change the one thing.

If the thing they want to change isn't in the SKILL.md (rare, but it happens if the default is in a helper script), tell them: "That one isn't in the SKILL.md, it's in [file]. Want me to change it there?"

### Step 5: Confirm

Show them what you changed in plain English:

> "Done. I changed the accent color in pdf-guide-test from orange (#d97757) to your blue (#4a90e2). The next PDF you generate will use blue instead."

Offer to change something else:

> "Want to tweak anything else?"

If they say no, end cleanly:

> "You're set. Your change is saved."

## Rules

- One edit per run, unless they explicitly ask to change multiple things.
- Never invent values. If they don't tell you the new color, ask.
- Never edit a skill they didn't ask about.
- Don't create a config file. Edit the skill file directly.
- No emdashes. Anywhere.
- Keep the whole thing under a minute. Two questions max.

## If they ask "can I change the defaults for all the skills at once?"

Answer honestly: "No, this skill changes one thing at a time. That's intentional. Most of the defaults work for most people, and one-off changes keep things simple. If you want to change the same thing across multiple skills (like your name on PDFs AND dashboards), run me again for each one."

## If they ask "how do I undo a change?"

Tell them: "Run me again and tell me what to revert it to. Or if you want the original defaults back, reinstall the plugin, which overwrites the skill files."
